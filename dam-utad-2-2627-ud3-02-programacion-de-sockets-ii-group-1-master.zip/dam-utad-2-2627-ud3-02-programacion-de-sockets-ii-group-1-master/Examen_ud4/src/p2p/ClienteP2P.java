package p2p;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

// Clase TCP
class ClienteTCP {
	private Socket socketCliente = null;
	private BufferedReader entrada = null;
	private PrintWriter salida = null;

	public ClienteTCP(String ip, int puerto) {
		try {
			socketCliente = new Socket(ip, puerto);
			System.out.println("Conexión TCP establecida con el servidor: " + socketCliente);
			entrada = new BufferedReader(new InputStreamReader(socketCliente.getInputStream(), StandardCharsets.UTF_8));
			salida = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(socketCliente.getOutputStream(), StandardCharsets.UTF_8)),
					true);
		} catch (IOException e) {
			System.err.printf("Imposible conectar con ip:%s / puerto:%d\n", ip, puerto);
			System.exit(-1);
		}
	}

	public void closeClienteTCP() {
		try {
			if (salida != null)
				salida.close();
			if (entrada != null)
				entrada.close();
			if (socketCliente != null)
				socketCliente.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Conexión TCP cerrada.");
	}

	public void enviarMsg(String linea) {
		salida.println(linea);
	}
	

	public String recibirMsg() {
		String msg = "";
		try {
			msg = entrada.readLine();
		} catch (IOException e) {
			System.err.println("Error al recibir mensaje: " + e.getMessage());
		}
		return msg;
	}
}

public class ClienteP2P {

	private final String ipServidor = "localhost";
	private final int puertoServidor = 5000;
	private DatagramSocket socketUdpServidor = null;
	private volatile boolean ejecutandoUdp = true;

	public static void main(String[] args) {
		ClienteP2P cliente = new ClienteP2P();
		cliente.ejecutar();
	}

	public void ejecutar() {
		Scanner sc = new Scanner(System.in);

		System.out.println("---- CLIENTE P2P (SESIÓN 2) ----");
		System.out.print("Introduce tu nombre de usuario: ");
		String nombre = sc.nextLine().trim();

		System.out.print("Introduce tu puerto UDP local de escucha (ej: 6001): ");
		int puertoUdpLocal = Integer.parseInt(sc.nextLine().trim());

	
		

		// Iniciar el hilo servidor UDP en segundo plano para atender descargas de otros usuarios
		iniciarServidorUdp(puertoUdpLocal);

		// Conectar al servidor central por TCP
		ClienteTCP canal = new ClienteTCP(ipServidor, puertoServidor);

		// Registrarse en el servidor
		String comandoRegistro = "REGISTER " + nombre + " " + puertoUdpLocal + " " ;
		canal.enviarMsg(comandoRegistro);
		String respRegistro = canal.recibirMsg();
		System.out.println("[Servidor]: " + respRegistro);

		if (respRegistro == null || !respRegistro.startsWith("OK")) {
			System.out.println("No se pudo completar el registro. Finalizando.");
			detenerServidorUdp();
			canal.closeClienteTCP();
			sc.close();
			return;
		}
		
	
	


		// Menú interactivo con SEARCH y descarga UDP integrados
		boolean conectado = true;
		while (conectado) {
			System.out.println("\n-----------------------------");
			
			System.out.println("4. APOSTAR");
			System.out.print("Elige una opción: ");

			String opcion = sc.nextLine().trim();

			switch (opcion) {
			
			case "4":
			case "APOSTAR":
				System.out.println("Introduce un numero del 1 al 10");
				String numero1 = sc.nextLine().trim();
				
				canal.enviarMsg("APOSTAR" + numero1);
				System.out.println(canal.recibirMsg());

			default:
				System.out.println("Opción no válida.");
				break;
			}
		}

		// Cierre ordenado de sockets y recursos
		detenerServidorUdp();
		canal.closeClienteTCP();
		sc.close();
	}

	// Lógica UDP
	private void iniciarServidorUdp(final int puertoUdp) {
		Thread hiloUdp = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					socketUdpServidor = new DatagramSocket(puertoUdp);
					byte[] bufferRecepcion = new byte[1024];

					while (ejecutandoUdp) {
						DatagramPacket paqueteRecibido = new DatagramPacket(bufferRecepcion, bufferRecepcion.length);
						socketUdpServidor.receive(paqueteRecibido);

						String mensaje = new String(paqueteRecibido.getData(), 0, paqueteRecibido.getLength(),
								StandardCharsets.UTF_8).trim();

						if (mensaje.startsWith("GET")) {
							String[] partes = mensaje.split("\\s+", 2);
							String archivoSolicitado = partes.length > 1 ? partes[1] : "archivo";

							String respuesta = "Archivo: " + archivoSolicitado + " 'contenido del archivo simulado'";
							byte[] datosEnvio = respuesta.getBytes(StandardCharsets.UTF_8);

							DatagramPacket paqueteRespuesta = new DatagramPacket(datosEnvio, datosEnvio.length,
									paqueteRecibido.getAddress(), paqueteRecibido.getPort());
							socketUdpServidor.send(paqueteRespuesta);
						}
					}
				} catch (SocketException e) {
				} catch (IOException e) {
					if (ejecutandoUdp) {
						System.err.println("Error en el receptor UDP: " + e.getMessage());
					}
				}
			}
		});

		hiloUdp.setDaemon(true);
		hiloUdp.start();
	}

	// Lógica de descarga


	private void detenerServidorUdp() {
		ejecutandoUdp = false;
		if (socketUdpServidor != null && !socketUdpServidor.isClosed()) {
			socketUdpServidor.close();
		}
	}
}