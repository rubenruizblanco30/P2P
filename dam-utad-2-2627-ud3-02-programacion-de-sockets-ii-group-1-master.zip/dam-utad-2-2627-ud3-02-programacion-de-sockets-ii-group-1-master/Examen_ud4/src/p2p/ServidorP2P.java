package p2p;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class ServidorP2P {

    // El mapa guarda los usuarios por su nombre.
    // Logger muestra información y errores en la consola del servidor.
    static HashMap<String, Usuario> usuarios = new HashMap<>();

    // Representa a un usuario con su IP, puerto UDP y archivos anunciados.
    static class Usuario {
        String ip;
        int puerto;
        List<String> archivos;

        // Guarda los datos recibidos al crear un usuario.
        Usuario(String ip, int puerto, List<String> archivos) {
            this.ip = ip;
            this.puerto = puerto;
            this.archivos = archivos;
        }
    }

    /*
     * Inicia el servidor TCP en el puerto 5000 y espera conexiones.
     * Cada cliente se atiende en un hilo diferente para permitir
     * varias conexiones simultáneas.
     */
    public static void main(String[] args) {
        try (ServerSocket servidor = new ServerSocket(5000)) {

            while (true) {
                Socket cliente = servidor.accept();
                

                Thread hilo = new Thread(() -> atender(cliente));
                hilo.start();
            }

        } catch (IOException e) {
        }
    }

    /*
     * Gestiona la comunicación con un cliente por TCP.
     * Lee sus mensajes y procesa REGISTER, LIST, SEARCH y UNREGISTER.
     * Envía las respuestas y elimina al usuario cuando detecta
     * que la conexión ha terminado, si seguía registrado.
     */
    static void atender(Socket cliente) {
        String nombre = null;

        try (Socket conexion = cliente;
             BufferedReader entrada = new BufferedReader(
                 new InputStreamReader(
                     conexion.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter salida = new PrintWriter(
                 new OutputStreamWriter(
                     conexion.getOutputStream(), StandardCharsets.UTF_8), true)) {

            String ip = conexion.getInetAddress().getHostAddress();
            String mensaje;

            while ((mensaje = entrada.readLine()) != null) {
            		Random random = new Random();
                mensaje = mensaje.trim();
                String linea = "APOSTAR 7";
                String [] partes = linea.trim().split("\\s+");
                String[] datos = mensaje.split("\\s+", 4);

                switch (datos[0]) {

                    case "REGISTER":
                        if (nombre != null) {
                            salida.println("ERROR Ya estas registrado");
                            break;
                        }

                        String respuesta = registrar(datos, ip);

                        if (respuesta.equals("OK")) {
                            nombre = datos[1];
                        }

                        salida.println(respuesta);
                        break;

                    case "LIST":
                        salida.println("OK " + listar());
                        break;

                    case "SEARCH":
                        String archivo = mensaje.substring(6).trim();

                        if (archivo.isEmpty()) {
                            salida.println("ERROR Uso: SEARCH archivo");
                        } else {
                            salida.println(buscar(archivo));
                        }
                        break;

                    case "UNREGISTER":
                        if (nombre == null) {
                            salida.println("ERROR No estas registrado");
                        } else {
                            eliminar(nombre);
                            nombre = null;
                            salida.println("OK");
                        }
                        break;
                     
                    case "APOSTAR":
					String[] apuesta = linea.trim().split("\\s+");
					
					if (apuesta[0].equalsIgnoreCase("APOSTAR")) {
						if(apuesta.length != 2 || !apuesta[1].matches("[1-9]|10")) {
							System.out.println("Introduce un numero del 1 al 10");
							
						}else {
							int numero = Integer.parseInt(apuesta[1]);
							int ganador = random.nextInt(1,11);
							if(numero == ganador) {
								salida.println("has ganado");
							}else {
								salida.println("Has perdido");
							}
						}
						continue;
					}

                    default:
                        salida.println("ERROR Comando desconocido");
                }
            }

        } catch (IOException e) {

        } finally {
            if (nombre != null) {
                eliminar(nombre);
            }
        }
    }

    /*
     * Comprueba que el registro incluya nombre y un puerto UDP válido,
     * y que el nombre no esté ocupado. Después guarda al usuario
     * y sus archivos anunciados en el mapa.
     * Devuelve OK si lo consigue o ERROR indicando el motivo.
     * synchronized coordina el acceso al mapa con los demás métodos
     * static synchronized de esta clase.
     */
    static synchronized String registrar(String[] datos, String ip) {
        if (datos.length < 3) {
            return "ERROR Uso: REGISTER nombre puertoUDP [archivo1,archivo2]";
        }

        String nombre = datos[1];
        int puerto;

        try {
            puerto = Integer.parseInt(datos[2]);
        } catch (NumberFormatException e) {
            return "ERROR Puerto UDP invalido";
        }

        if (puerto < 1 || puerto > 65535) {
            return "ERROR Puerto UDP invalido";
        }

        if (usuarios.containsKey(nombre)) {
            return "ERROR Nombre en uso";
        }

        List<String> archivos = new ArrayList<>();

        if (datos.length == 4) {
            archivos = Arrays.asList(datos[3].split("\\s*,\\s*"));
        }

        usuarios.put(nombre, new Usuario(ip, puerto, archivos));

        return "OK";
    }

    /*
     * Devuelve los nombres de los usuarios registrados,
     * separados por comas. El orden puede variar.
     */
    static synchronized String listar() {
        return String.join(",", usuarios.keySet());
    }

    /*
     * Busca un usuario que anuncie el nombre exacto del archivo.
     * Devuelve FOUND con su IP y puerto UDP para que el cliente
     * pueda contactarlo, o NOT_FOUND si nadie lo anuncia.
     */
    static synchronized String buscar(String archivo) {
        for (Usuario usuario : usuarios.values()) {
            if (usuario.archivos.contains(archivo)) {
                return "FOUND " + usuario.ip + " " + usuario.puerto;
            }
        }

        return "NOT_FOUND";
    }

    /*
     * Elimina al usuario del mapa y muestra su baja
     * junto con los usuarios que quedan registrados.
     */
    static synchronized void eliminar(String nombre) {
        usuarios.remove(nombre);
    }
}